package org.zodzp.dvasem.Model;

public class ConfigDate {
    public String date;
}
