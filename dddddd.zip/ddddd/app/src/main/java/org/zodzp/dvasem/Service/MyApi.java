package org.zodzp.dvasem.Service;

import org.zodzp.dvasem.Model.ConfigDate;
import org.zodzp.dvasem.Model.DataItem;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MyApi {
    @GET("db.json")
    Call<DataItem> data();

    @GET("date.json")
    Call<ConfigDate> date();

}
